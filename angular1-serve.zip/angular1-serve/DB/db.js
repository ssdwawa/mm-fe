var sql={
    companyList:'SELECT * FROM companyList WHERE companyId LIKE ?',
    positionList:'SELECT * FROM positionList',
    addUser:'INSERT INTO user VALUES (null,?,?,?)',
    addCompany:'INSERT INTO companyList VALUES(null,?,?,?,?,?,?,?)',
    // ourCompany:'SELECT * FROM companyList'
    checkUser:'SELECT * FROM user WHERE userName LIKE ? AND pass LIKE ?',
    checkAccount:'SELECT * FROM user WHERE userName LIKE ?',
    checkCompany:'SELECT * FROM companyList WHERE account LIKE ?',
    updatecompany:'UPDATE companyList set companyName=? , imageUrl = ? , address = ? , member = ? , ins = ?,  state =? WHERE  companyId=? ',
    addWork:'INSERT INTO worklist VALUES (null,?,?,?,?,?,?,?)',
    loadWorkList:'SELECT * FROM worklist WHERE comId LIKE ? LIMIT ?,?'
}

module.exports=sql