var express = require('express');
const multer = require('multer');
const path = require('path');
var router = express.Router();
var mysql = require('mysql');
var config = require('../DB/config.js');
var async = require("async");
var sql = require('../DB/db.js')
var multiparty = require('multiparty');
var pool = mysql.createPool(config.mysql)
const app = express();

var date = {
  coName: '',
  coAdd: '',
  coXz: '',
  coSta: '',
  coGm: '',
  imgurl: '',
  acco:'',
  comId:''
}

// app.use(express.static('../public')); const storage = multer.diskStorage({
// destination: function (req, file, cb) {     cb(null,
// path.resolve('public/images'));   },   filename: function (req, file, cb) {
// cb(null, Date.now() + path.extname(file.originalname));   } }); var upload =
// multer({storage: storage});

router.post('/addUser', function (req, res, next) {
  console.log(`req is ${req}`)
  var userName = req.param('userName'),
    pass = req.param('pass'),
    wat = req.param('wat');
  pool.getConnection((err, connection) => {
    if (connection) {
      console.log(`connection is ${connection}`)
      connection.query(sql.addUser, [
        userName, pass, wat
      ], function (err1, doc) {
        if (doc) {
          res.json({stasus: 1, msg: doc})
        } else if (err) {
          console.log(`err1 is ${err1}`)
        }
        connection.release()
      })
    } else if (err) {
      console.log(`err is ${err}`)
    }
  })
});

router.post('/profile', function (req, res, next) {
  var form = new multiparty.Form();
  //定义储存的路径
  form.uploadDir = "public/images";
  async.series([
    function (cb) {
      form
        .parse(req, function (err, fields, files) {
          console.log(files);
          console.log(fields);
          var arr = [];
          date.coName = fields['co-name'][0];
          date.coAdd = fields['co-add'][0];
          date.coXz = fields['co-xz'][0];
          date.coSta = fields['co-sta'][0];
          date.coGm = fields['co-gm'][0];
          date.acco= fields['co-acc'][0];
          if (files['avatar']) {
            arr = files['avatar'][0]['path'].split('/');
            date.imgurl=`/images/${arr[arr.length-1]}`;
          }
          console.log(date.imgurl);
          cb();
        });
    },
    function (cb) {
      pool.getConnection((err, connection) => {
        if (connection) {
          connection
            .query(sql.addCompany, [
              date.coName,
              date.imgurl,
              date.coAdd,
              date.coGm,
              date.coXz,
              date.coSta,
              date.acco
            ], function (err1, doc) {
              if (doc) {
                res.json({err: null, msg: 'ok'});
              } else if (err1) {
                console.log(`err1 is ${err1}`)
              }
              connection.release()
            })
        } else if (err) {
          console.log(err)
        }
      })
      cb();
    }
  ])

});

router.post('/login',function(req,res,next){
  var userName= req.body.userName,
      userPwd= req.body.userPwd;

  pool.getConnection((err,connection)=>{
    if(err){
      console.log(err);
    }else if(connection){
      connection.query(sql.checkUser,[userName,userPwd],function(err1,doc){
        if(doc){
          res.json({
            staus:1,
            msg:doc
          })
        }else if(err1){
          res.json({
            staus:0,
            msg:err1
          })
        }
        connection.release()
      })
    }
  })
});

router.post('/check',(req,res,next)=>{
  var userName = req.body.userName;
  pool.getConnection((err,connection)=>{
    if(err){
      console.log(err)
    }else if(connection){
      connection.query(sql.checkAccount,[userName],(err1,doc)=>{
        if(doc.length>0){
          res.json({
            stasus:1,
            msg:doc
          })
        }else{
          res.json({
            stasus:0,
            msg:'ok'
          })
        }
        connection.release()
      })
    }
  })  
});

router.post('/checkCompany',(req,res,next)=>{
  var userName = req.body.data.userName;
  console.log(userName)
  pool.getConnection((err,connection)=>{
    if(err){
      console.log(err)
    }else if(connection){
      connection.query(sql.checkCompany,[userName],(err1,doc)=>{
        if(doc){
          res.json({
            stasus:1,
            msg:doc
          })
        }else{
          res.json({
            stasus:0,
            msg:err1
          })
        }
        connection.release()
      })
    }
  }) 
})

router.post('/updateCom',(req,res,next)=>{
  var form = new multiparty.Form();
  form.uploadDir = "public/images";
  async.series([
    function (cb) {
      form
        .parse(req, function (err, fields, files) {
          var arr = [];
          date.coName = fields['co-name'][0];
          date.coAdd = fields['co-add'][0];
          date.coXz = fields['co-xz'][0];
          date.coSta = fields['co-sta'][0];
          date.coGm = fields['co-gm'][0];
          date.comId= fields['co-comId'][0];
          // console.log(`is change ${files[0]}`)
          if (files.avatar) {
            console.log(files);
            arr = files['avatar'][0]['path'].split('/');
            date.imgurl=`/images/${arr[arr.length-1]}`;
          }
          else{
            date.imgurl=fields['co-oldImg'][0]
          }
          console.log(date.imgurl);
          cb();
        });
    },
    function (cb) {
      pool.getConnection((err, connection) => {
        if (connection) {
          connection
            .query(sql.updatecompany, [
              date.coName,
              date.imgurl,
              date.coAdd,
              date.coGm,
              date.coXz,
              date.coSta,
              date.comId
            ], function (err1, doc) {
              if (doc) {
                res.json({err: null, msg: 'ok'});
              } else if (err1) {
                console.log(`err1 is ${err1}`)
              }
              connection.release()
            })
        } else if (err) {
          console.log(err)
        }
      })
      cb();
    }
  ])
})
module.exports = router;

// app   .route('/api/uppic')   .post(function (req, res) {     var multiparty =
// require('multiparty');     var form = new multiparty.Form(); //新建表单 //设置编辑
//  form.encoding = 'utf-8';     //设置图片存储路径     form.uploadDir =
// "Uploads/gaoxiao/";     form.keepExtensions = true; //保留后缀 form.maxFieldsSize
// = 2 * 1024 * 1024; //内存大小     form.maxFilesSize = 5 * 1024
// * 1024; //文件字节大小限制，超出会报错err     //表单解析     form.parse(req, function (err,
// fields, files) {       //报错处理       if (err) {         console.log(err);
// var u = {           "error": 1,           "message": '请上传5M以图片'         };
//      res.end(JSON.stringify(u));         return false;       } //获取路径
// var oldpath = files.imgFile[0]['path'];       //文件后缀处理格式 if
// (oldpath.indexOf('.jpg') >= 0) {         var suffix = '.jpg';       } else if
// (oldpath.indexOf('.png') >= 0) {         var suffix = '.png';       } else if
// (oldpath.indexOf('.gif') >= 0) {         var suffix = '.gif';       } else {
//        var u = {           "error": 1,           "message": '请上传正确格式'    };
//       res.end(JSON.stringify(u));         return false;       } var u = {
//     "error": 0,         "url": '/' + url       } res.end(JSON.stringify(u));
//    });   });