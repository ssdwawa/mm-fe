var express = require('express');
var router = express.Router();

var mysql = require('mysql');
var config = require('../DB/config.js')
var sql = require('../DB/db.js')
var pool = mysql.createPool(config.mysql)

router.get('/positionList', (req, res, next) => {
  var page = parseInt(req.param('page'));
  var pageSize = 8;
  var skip = (page - 1) * pageSize;
  pool.getConnection((err, connection) => {
    if (err) {
      console.log(err)
    } else {
      connection
        .query(sql.positionList, function (err2, doc1) {
          if (err2) {
            console.log(`err2 is ${err2}`)
          } else {
            console.log(`公司列表有${doc1}`);
            res.json({
              stasus: 1,
              msg: doc1
            })
          }
          connection.release()
        })
    }
  })
});
router.get('/ourcompany',(req,res,next)=>{
  pool.getConnection((err,connection)=>{
    if(err){
      console.log(err)
    }else if(connection){
      connection.query(sql.ourCompany,function(err1,doc){
        if(doc){
          res.json({
            stasus: 1,
            msg: doc
          })
        }
        connection.release()
      })
    }
  })
})
module.exports = router;
