var express = require('express');
var router = express.Router();

var mysql = require('mysql');
var config = require('../DB/config.js')
var sql = require('../DB/db.js')
var pool = mysql.createPool(config.mysql)


router.post('/addWork',(req,res,next)=>{
    var workName=req.body.workName;
    var workXz=req.body.workXz;
    var workSalra=req.body.workSalra;
    var workAcc=req.body.workAcc;
    var workReq=req.body.workReq;
    var workComId=req.body.workComId;
    var workComImg=req.body.workComImg;
    pool.getConnection((err1,connection)=>{
        if(err1){
            console.log(err1)
        }
        else{
            connection.query(sql.addWork,[workName,workXz,workSalra,workAcc,workReq,workComId,workComImg],(err2,doc)=>{
                if(err2){
                    console.log(err2)
                }
                else{
                    res.json({
                        stasus:1,
                        msg:doc
                    })
                }
                connection.release()
            })
        }
    })
});
router.post('/loadWorkList',(req,res,next)=>{
    var page = parseInt(req.param('page'));
    var comId = req.param('comId');
    var pageSize = 9;
    var skip = (page - 1) * pageSize;
    pool.getConnection((err1,connection)=>{
        if(err1){
            console.log(err1)
        }
        else{
            connection.query(sql.loadWorkList,[comId,8*page,pageSize],(err2,doc)=>{
                if(err2){
                    console.log(err2)
                }
                else{
                    res.json({
                        stasus:1,
                        msg:doc
                    })
                }
            })
        }
        connection.release()
    })
})
router.get('/positionList', (req, res, next) => {
  var page = parseInt(req.param('page'));
  var comId = req.param('comId');
  var pageSize = 8;
  var skip = (page - 1) * pageSize;
  pool.getConnection((err, connection) => {
    if (err) {
      console.log(err)
    } else {
      connection
        .query(sql.loadWorkList, [comId,8*page,page],function (err2, doc1) {
          if (err2) {
            console.log(`err2 is ${err2}`)
          } else {
            console.log(`公司列表有${doc1}`);
            res.json({
              stasus: 1,
              msg: doc1
            })
          }
          connection.release()
        })
    }
  })
});

module.exports = router;